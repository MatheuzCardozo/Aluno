//Conecção com a API
const BASEURL = "http://localhost:3000";

export {BASEURL}